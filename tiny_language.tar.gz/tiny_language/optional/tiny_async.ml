(** *********************************
* 			Advanced Programming			  *
*					HW1	2015/2016						  *
* 	The Tiny language interpreter   *
* 				(mandatory part)				  *
********************************* **)

open Async.Std;;

let rec check_dup l = 
	match l with
	| [] -> false
  | (h::t) ->
    let x = (List.filter (fun x -> x = h) t) in
    	if (x = []) 
			then check_dup t
      else true
;;

(************************************************************)
(*                          BASE                            *)
(************************************************************)
type ide = string;;
type loc = int;;

type exp =
	| EEmpty
	| EBool of bool
	| EInt of int
	| EString of string
	| ENewRecord of (ide * exp) list * (ide * exp) list (*fields, methods*)
	| ERecordMethod of (exp * ide * (exp list)) (*record, method name, params*)
	| EIde of ide
	|	ESum of exp * exp
	| EDiff of exp * exp
	| EProd of exp * exp
	| EEqint of exp * exp
	| ELessint of exp * exp
	| EComparestring of exp * exp
	| EEqstring of exp * exp
	| EConcatString of exp * exp
	| EOr of exp * exp
	| EAnd of exp * exp
	| ENot of exp
	| EIfthenelse of exp * exp * exp
	| ELet of ide * exp * exp
	| EFund of (ide * typ) list * (exp * typ) (*fun definition*)
	| EApplyf of exp * exp list (*fun application*)
	| ERecf of ide * exp (*recursive fun definition*)
	| ERef of exp (*takes an exp and gives an exp ref*)
	| EDeref of exp (*the opposite *)
	|	EAssign of ide * exp (*assignement is allowed only to ref identifier*)
	| ESeq of exp * exp
	| EWhile of exp * exp
	| EBreak
	| EContinue
	| EReturn of exp
	| EPrint of exp
	| EEval of exp (**opt*)
	| ESleepf of int

and value =
	| RefV of value ref
	| UndefinedV
	| BoolV of bool
	| IntV of int
	| StringV of string
	| RecordV of (ide * value) list * (ide * exp) list * env * (store ref)
	| FunV of efun and efun = (exp * env) (*a closure!*)

and typ =
	| RefT of typ ref
	| UndefinedT
	| BoolT
	| IntT
	| StringT
 	| FunT of typ list * typ
	| RecordT of (ide * typ) list * (ide * typ) list

and env =	ide -> loc
and store =	loc -> value

and jumps =
	| JBreak
	| JContinue
	| JReturn of value
;;
exception Jump of jumps;;

(************************************************************)
(*                       STRINGIFY                          *)
(************************************************************)

let rec string_of_expr e =
	match e with
	| EEmpty -> "EEmpty "
	| EInt n -> string_of_int n
	| EBool b -> string_of_bool b
	| EString str -> str
	| ENewRecord (fields, methods) -> (*only the ides, too verbose otherwise*)
			let ff = String.concat ";" (List.map (fun a -> fst a) fields) in 
			let mm = String.concat ";" (List.map (fun a -> fst a) methods) in 
			"ERecord{field:" ^ ff ^ "methods:" ^ mm ^ "}"
	| ERecordMethod (record, method_name, args) -> 
			let x = String.concat "," (List.map (fun a -> string_of_expr a) args) in 
			string_of_expr record ^ "." ^ method_name ^ x
	| EIde i -> i
	| ESum (a, b) -> "(" ^ string_of_expr a ^ "+" ^ string_of_expr b ^ ")"
	| EDiff (a, b) ->  "(" ^ string_of_expr a ^ "-" ^ string_of_expr b ^ ")"
	| EProd (a, b) -> "(" ^ string_of_expr a ^ "*" ^ string_of_expr b ^ ")"
	| EEqint (a, b) -> "(" ^ string_of_expr a ^ "==" ^ string_of_expr b ^ ")"
	| ELessint (a, b) -> "(" ^ string_of_expr a ^ "<" ^ string_of_expr b ^ ")"
	| EComparestring (a, b) -> "(" ^ "compare_string " ^ string_of_expr a ^ " " ^ string_of_expr b ^ ")"
	| EEqstring (a, b) -> "(" ^ string_of_expr a ^ "==" ^ string_of_expr b ^ ")"
	| EConcatString (a, b) -> "(" ^ "concat_string " ^ string_of_expr a ^ " " ^ string_of_expr b ^ ")"
	| EOr (a, b) -> "(" ^ string_of_expr a ^ "||" ^ string_of_expr b ^ ")"
	| EAnd (a, b) -> "(" ^ string_of_expr a ^ "&&" ^ string_of_expr b ^ ")"
	| ENot a -> "(not " ^ string_of_expr a ^ ")"
	| EIfthenelse (c, e1, e2) ->
			"if(" ^ string_of_expr c ^ ") \n" ^
			"then \n " ^
			"\t " ^ string_of_expr e1 ^ "\n" ^
			"else \n " ^
			"\t " ^ string_of_expr e2 ^ "\n"
	| ELet (i, e1, e2) -> 
			"let " ^ i ^ " = " ^ string_of_expr e1 ^ " in " ^ "\n" ^ string_of_expr e2 
	| EFund (args, f) -> 
			let x = String.concat "," (List.map (fun a -> (fst a) ^ ":" ^ string_of_type (snd a)) args) in 
			"fund(" ^ x ^ "):" ^ string_of_type (snd f) ^ " ->\n\t" ^ string_of_expr (fst f)
	| EApplyf (f, args) -> 
			let x = String.concat "," (List.map (fun a -> string_of_expr a) args) in 
			"applyf " ^ string_of_expr f ^ x
	| ERecf (fname, expr) -> "recfund " ^ fname ^ " ->\n\t" ^ string_of_expr expr
	| ERef expr -> "ref" ^ "(" ^ string_of_expr expr ^ ")" 
	| EDeref exprr -> "!" ^ string_of_expr exprr
	| ESeq (a, b) -> string_of_expr a ^ "; " ^ string_of_expr b
	| EAssign (i, expr) -> i ^ ":=" ^ string_of_expr expr
	| EBreak -> "break"
	| EContinue -> "continue"
	| EReturn expr -> "return " ^ string_of_expr expr
	| EWhile (c, body) ->
			"while(" ^ string_of_expr c ^ ")" ^ "\n" ^
			"\t(" ^ string_of_expr body ^ ")\n"
	| EPrint ex -> "print " ^ string_of_expr ex
	| ESleepf secs -> "sleepf " ^ string_of_int secs
	| EEval a -> "eval " ^ string_of_expr a (**opt*)

and string_of_value v =
	match v with
	| UndefinedV -> "undefinedV"
	| IntV n -> string_of_int n
	| BoolV b -> string_of_bool b
	| StringV s -> s
	| FunV f ->
			(match f with
			| (EFund (args, f), r) ->
					let x = String.concat "," (List.map (fun a -> (fst a) ^ ":" ^ string_of_type (snd a)) args) in 
					"funV(" ^ x ^ "):" ^ string_of_type (snd f) ^ " ->\n\t" ^ string_of_expr (fst f)
			| _ -> failwith "string_of_value FunV failure")
	| RefV r -> "refV" ^ string_of_value !r
	| RecordV (fields, methods,_,_) ->
			let ff = String.concat ";" 
				(List.map (fun a -> fst a ^ ":" ^ string_of_value (snd a)) fields) in 
			let mm = String.concat ";" 
				(List.map (fun a -> fst a ^ ":" ^ string_of_expr (snd a)) methods) in 
			"recordV{field:" ^ ff ^ "methods:" ^ mm ^ "}"

and string_of_type t =
	match t with
	| RefT rt -> "reft" ^ string_of_type !rt
	| UndefinedT -> "UndefinedT"
	| IntT -> "IntT"
	| BoolT -> "BoolT"
	| StringT -> "StringT"
	| FunT (args_t,f_t)  -> 
  		let x = String.concat "," (List.map (fun a -> string_of_type a) args_t) in 
  		"FunT([" ^ x ^ "]," ^ string_of_type f_t ^ ")"
	| RecordT(fields, methods) -> 
			let ff = String.concat ";" 
				(List.map (fun a -> fst a ^ ":" ^ string_of_type (snd a)) fields) in 
			let mm = String.concat ";" 
				(List.map (fun a -> fst a ^ ":" ^ string_of_type (snd a)) methods) in 
			"RecordV{field:" ^ ff ^ "methods:" ^ mm ^ "}"
;;

(************************************************************)
(*                 ENVIRONMENT AND STORE                    *)
(************************************************************)

(* Differently from what we have seen in classroom, we use two repositories to accompany     *)
(*  the evaluation of an expression, not one. One of them, the environment, continues to be  *)
(* responsible for maintaining lexical scope. The other one maintain the dynamic state of    *)
(* mutated variable. This latter data structure is called the store.                         *)

exception EmptyEnv;;
let emptyenv (y : ide) = raise EmptyEnv;;

let applyenv (r : env) (x : ide) = r x;;
let bind (x : ide) (v : loc) (r : env) : env =
	fun y -> if y = x then v else r y;;
let rec bindlist (r, il, el) =
	match (il, el) with
	| ([], []) -> r
	| (i :: il1, e :: el1) -> bindlist ((bind i e r), il1, el1)
	| _ -> failwith "WrongBindlist"
;;

let (newloc, initloc) =
	let count = ref (-1) in 
	((fun () -> (count := !count + 1; !count)), (fun () -> count := (-1)))
;;
	
exception EmptyStore;;
let emptystore (v: loc) = (initloc (); raise EmptyStore);;

let applystore (s : store) (x : loc) = s x;;
let allocate ((s : store), (v : value)) =
	let l = newloc () in 
	(l, (fun y -> if y = l then v else s y : store))
;;
let allocatelist (s, vl) = 
	let rec allocatelist' (ll, s') vl' =
		(match vl' with
		| [] -> (ll, s')
		| v :: vtl ->
				let a = allocate (s', v) (* @ operator to avoid reversing the list*)
				in allocatelist' ((ll @ [ fst a ]), (snd a)) vtl)
	in  allocatelist' ([], s) vl
;;
let update (x : loc) (v : value) (s : store) : store =
	fun y -> if y = x then v else s y
;;

	
(************************************************************)
(*                   TYPED OPERATIONS                       *)
(************************************************************)


let arith_int_binop ( (op:int->int->int), (l:value), (r:value)) : value =
	(*things such division by 0 are managed by Ocaml interpreter*)
	(match (l, r) with
	| (IntV a, IntV b) -> IntV (op a b) 
	| _ -> failwith "type error arith_binop")
;;
let logic_int_binop ( (op:int->int->bool), (l:value), (r:value)) : value =
	(match (l, r) with
	| (IntV a, IntV b) -> BoolV (op a b)
	| _ -> failwith "type error logic_int_binop")
;;
let compare_string (x, y) =
	(match (x, y) with
	| (StringV a, StringV b) -> IntV(compare a b)
	| _ -> failwith "type error compare_string")
;;
let eqstring (x, y) =
	(match compare_string(x,y) with
	| v when v==IntV(0) -> BoolV(true)
	| _ -> BoolV(false))
;;
let concat_string (x, y) =
	(match (x, y) with
	| (StringV a, StringV b) -> StringV (a ^ b)
	| _ -> failwith "type error concat_string")
;;
let logic_bool_binop ( (op:bool->bool->bool), (l:value), (r:value)) : value =
	(match (l, r) with
	| (BoolV a, BoolV b) -> BoolV (op a b)
	| _ -> failwith "type error logic_bool_binop")
;;
let not_f x =
	(match x with 
	| BoolV a -> BoolV (not a)
	| _ -> failwith "type error not")
;;

(************************************************************)
(*                        SEM_EAGER                         *)
(************************************************************)

let rec sem_eager (e : exp) (r : env) (s : store ref) =
	match e with
	| EEmpty -> UndefinedV
	| EInt n -> IntV n
	| EBool b -> BoolV b
	| EString str -> StringV str
	| ENewRecord (fields, methods) -> (makerecord (fields, methods))
	| ERecordMethod (record, method_name, args) ->
				(match (sem_eager record r s) with
				| RecordV (flds, meths, nv_, s_)-> 
					let m = 
						try List.assoc method_name meths
						with _ -> failwith 
							("method " ^ method_name ^ "does not exist in record " ^ (string_of_expr record)) in
  				(applyfun ((EApplyf (m, args)), nv_, s_))
				| _ -> failwith "invoking a method from a non Record object")
	| EIde i -> 
			( try (applystore !s (applyenv r i)) with _ -> failwith ( "unbound ide " ^ i) )
	| ESum (a, b) -> arith_int_binop((+),sem_eager a r s, sem_eager b r s)
	| EDiff (a, b) ->  arith_int_binop((-),sem_eager a r s, sem_eager b r s)
	| EProd (a, b) -> arith_int_binop(( * ),sem_eager a r s, sem_eager b r s)
	| EEqint (a, b) -> logic_int_binop((==),sem_eager a r s, sem_eager b r s)
	| ELessint (a, b) -> logic_int_binop((<),sem_eager a r s, sem_eager b r s)
	| EComparestring (a, b) -> compare_string(sem_eager a r s, sem_eager b r s)
	| EEqstring (a, b) -> eqstring(sem_eager a r s, sem_eager b r s)
	| EConcatString (a, b) -> concat_string(sem_eager a r s, sem_eager b r s)
	| EOr (a, b) -> logic_bool_binop((||),sem_eager a r s, sem_eager b r s)
	| EAnd (a, b) -> logic_bool_binop((&&),sem_eager a r s, sem_eager b r s)
	| ENot a -> not_f(sem_eager a r s)
	| EIfthenelse (c, e1, e2) ->
			let c_v = sem_eager c r s in
			if (type_of_value c_v == BoolT) 
			then
				(*Must we ensure that both branches have same type?*)
				(*It is a semantic decision*)
				if (type_inf e1 r s == type_inf e2 r s)
				then
    			(match c_v with
    			| BoolV true -> sem_eager e1 r s
    			| BoolV false -> sem_eager e2 r s
    			| _ -> failwith "") (*never here*)
  			else failwith "wrong types in EIfthenelse branches"
			else failwith "wrong type in EIfthenelse guard"
	| ELet (i, e1, e2) ->
			let (l, s') = allocate (!s, (sem_eager e1 r s))
			in s:=s'; sem_eager e2 (bind i l r) s
	| EFund (args, f) -> makefun(e, r)
	| EApplyf (f, args) -> applyfun(e, r, s)
	| ERecf (fname, expr) -> makefunrec(fname, expr, r, s)
	| ERef expr -> RefV(ref(sem_eager expr r s))
	| EDeref exprr ->
				(match (sem_eager exprr r s) with
				| RefV valr -> (!valr)
				| _ -> failwith "Trying to dereference a non-reference")
	| ESeq (a, b) -> let _ = sem_eager a r s in sem_eager b r s
	| EAssign (i, expr) -> (*cheks both if it exists and if it is a ref value*) 
				(match applystore !s (applyenv r i) with
  			| RefV refv -> 
					(*we deny references to be assigned arbitrary values (e.g. it's not like C)*)
					if (type_of_value (!refv) == type_inf expr r s)
					then
  					(s:= update (applyenv r i) (RefV(ref(sem_eager expr r s))) (!s);(UndefinedV))
					else
    				failwith "Assign with different types"
  			| _ -> failwith "Assign to a non-reference variable")
	| EBreak -> raise (Jump JBreak)
	| EContinue -> raise (Jump JContinue)
	| EReturn expr -> raise (Jump (JReturn (sem_eager expr r s)))
	| EWhile (c, body) ->
  		(try 
  			(let c_v = sem_eager c r s in
    		if (type_of_value c_v == BoolT) 
    		then
      		(match c_v with
      		| BoolV true -> sem_eager (ESeq (body, (EWhile (c, body)))) r s
      		| BoolV false -> (UndefinedV)
      		| _ -> failwith "")(*never here*)
    		else failwith "wrong guard in EWhile")
			with
			| Jump JBreak -> UndefinedV
			| Jump JContinue -> sem_eager (EWhile(c, body)) r s
			| Jump (JReturn expr) -> raise (Jump (JReturn expr)) ) (*propagate*)
	| EPrint e ->
			(print_string (string_of_value ((sem_eager e r s))); (UndefinedV))
	| ESleepf secs ->
			(print_string ("sleeps for " ^ (string_of_int secs) ^ " secs and returning \n");
			for i = 0 to (secs*10000000) do ignore(sin(float_of_int i)) done;	
			UndefinedV)
	| EEval a ->
		 (*Deferred.bind d f takes a deferred value d and a function f that is to be run with the value of d once it's determined*)
     let ivar = Ivar.create () in
     let def = Ivar.read ivar in
     (match (Ivar.fill ivar (sem_eager a r s);Deferred.peek def) with
      | Some v -> v
      | _ -> failwith "No Value in EEval")

and makefun ((e : exp), (r : env)) =
	match e with
	| EFund (args, f) -> FunV (e, r)
	| _ -> failwith "Non-functional object in makefun"

and makefunrec (i, e, (r : env), (s : store ref)) =
	let loc = newloc () in
	let calculateenv (r' : env) =
		(s:= update loc (makefun (e, r')) !s; bind i loc r) in
	let rec rfix x = calculateenv rfix x
	in (s:=(update loc (makefun (e, rfix)) !s); makefun (e, rfix))

and applyfun ((e : exp), (r : env), (s : store ref)) =
	match e with
	| EApplyf (f, args) -> (*we adopt call-by-value (not reference)*)
			(let clos = sem_eager f r s in
			let argvals = sem_eager_list args r s in 
			let (ll, s') = allocatelist (!s, argvals) in
			s:=s'; match clos with
				| FunV ((EFund (args_, f_)), env) -> 
						(try
							sem_eager (fst f_) (bindlist (env, (List.map (fun a -> fst a) args_), ll)) s
						with
						| Jump (JReturn v) -> v
      			| _ as x-> print_string (Printexc.to_string x); failwith "wrong Jump in function application (only JReturn is permitted)" )
				| _ -> failwith "attempt to apply a non-functional")
	| _ -> failwith "attempt to apply a non-functional object"

and sem_eager_list el r s =
	match el with
	| [] -> []
	| e :: tl ->
			let sem_e = sem_eager e r s
			in sem_e :: (sem_eager_list tl r s)

and makerecord ((fields : (ide * exp) list), (methods : (ide * exp) list)) =

 	let (fields_i,fields_e) = List.split fields in
	let (methods_i,methods_e) = List.split methods in

  (*Duplicate ides are not allowed*)
	if not(check_dup(fields_i@methods_i)) 
	then
  	(*Methods must be EFunds (or method invocation would fail)    *)
  	if (List.for_all (fun a -> match a with 
  		| EFund(_,_) -> true
  		| _ -> false ) methods_e)
  	then
    	let s = ref emptystore in
    	
    	let fields_v = (sem_eager_list fields_e emptyenv s) in
    	let (ll, s') = allocatelist ((!s), fields_v) in
    	let nv = bindlist (emptyenv, fields_i, ll) in
    
    	let methods_v = (sem_eager_list methods_e nv (ref s')) in	
    	let (ll, s') = allocatelist ((s'), methods_v ) in
    	let nv = bindlist (nv, methods_i, ll) in
    	
  		let fld = List.combine fields_i fields_v in
  		let meth = List.combine methods_i methods_e in
  		(s := s'; RecordV (fld, meth, nv, s))
			
  	else
  		failwith "wrong record construction, methods must be EFunds"
	else
		failwith "duplicate ide in record creation"
			
	

	
and exp_of_type t = 
	match t with
	| RefT rt -> ERef ((exp_of_type !rt))
  | UndefinedT -> EEmpty
  | IntT -> EInt 0
  | BoolT -> EBool false
  | StringT -> EString ""
	| FunT(at,rt) -> (*a lil' dirty*)
			let fake_args = List.map (fun a -> (string_of_int (Random.int 999),a)) at in
			EFund (fake_args, (exp_of_type rt,rt))
	| RecordT(fields, methods) -> 
			let ff = List.map (fun a -> (fst a,exp_of_type (snd a))) fields in 
			let mm = List.map (fun a -> (fst a,exp_of_type (snd a))) methods in 
			ENewRecord(ff,mm)


and value_of_type t = 
	sem_eager (exp_of_type t) emptyenv (ref emptystore)

and type_of_value (v:value) =
	match v with
	| RefV rv -> RefT (ref (type_of_value !rv))
  | UndefinedV -> UndefinedT
  | IntV _ -> IntT
  | BoolV _ -> BoolT
  | StringV _ -> StringT
	| FunV fv -> 
		(match fv with
		| (EFund(args_, f_),nv) -> 
				FunT(List.map (fun a -> snd a) args_,snd f_)
		| _ -> failwith "Not an EFund in type_of_value FunV" )
	| RecordV(fields, methods,_,_) -> 
			let ff = List.map (fun a -> (fst a,type_of_value (snd a))) fields in 
			let mm = List.map (fun a -> (fst a,FunT([],UndefinedT))) methods in (*well, ok*)
			RecordT(ff,mm)

and type_inf (e:exp) (r:env) (s:store ref) = 
	match e with
  | EEmpty -> UndefinedT
  | EInt _ -> IntT
  | EBool _ -> BoolT
  | EString _ -> StringT
	| ENewRecord(fields, methods) -> type_of_value (makerecord(fields, methods))
	| ERecordMethod (record, method_name, args) ->
				(match (sem_eager record r s) with
				| RecordV (flds, meths, nv_, s_)-> 
					let m = 
						try List.find (fun a -> fst a = method_name) meths
						with _ -> failwith 
							("method " ^ method_name ^ "does not exist in record " ^ (string_of_expr record)) in
  				(type_inf (EApplyf (snd m, args)) r s)
				| _ -> failwith "invoking a method from a non Record object")
  | EIde(i) -> (type_of_value (applystore !s (applyenv r i)))
  | ESum(a,b)
  | EDiff(a,b)
  | EProd(a,b) ->
			if ( (type_inf a r s == IntT) && (type_inf b r s == IntT) )
			then IntT
			else failwith "type_inf error in ESum/EDiff/EProd"
	| EEqint (a, b)
	| ELessint (a, b) ->
			if ( (type_inf a r s == IntT) && (type_inf b r s == IntT) )
			then BoolT
			else failwith "type_inf error in EEquint/ELessint"
	| EComparestring (a, b) ->
			if ( (type_inf a r s == StringT) && (type_inf b r s == StringT) )
			then IntT
			else failwith "type_inf error in EComparestring"
	| EEqstring (a, b) -> 
			if ( (type_inf a r s == StringT) && (type_inf b r s == StringT) )
			then BoolT
			else failwith "type_inf error in EEqstring"
	| EConcatString (a, b) ->
			if ( (type_inf a r s == StringT) && (type_inf b r s == StringT) )
			then StringT
			else failwith "type_inf error in EConcatString"
	| EOr (a, b)
	| EAnd (a, b) ->
			if ( (type_inf a r s == BoolT) && (type_inf b r s == BoolT) )
			then BoolT
			else failwith "type_inf error in EOr/EAnd"
	| ENot a ->
			if ( type_inf a r s == BoolT )
			then BoolT
			else failwith "type_inf error in ENot"
  | EIfthenelse(c,e1,e2) ->
			let c_t = type_inf c r s in
			if (c_t == BoolT)
			then 
  			let e1_t = type_inf e1 r s in
  			let e2_t = type_inf e2 r s in
				if (e1_t == e2_t)
  			then e1_t
  			else failwith "different types in EIfthenelse branches"
			else failwith "wrong type in EIfthenelse guard"
	| ELet (i, e1, e2) -> 
			let (l, s') = allocate (!s, (sem_eager e1 r s)) in 
			type_inf e2 (bind i l r) (ref s')
	| EFund (args, f) ->
			let (args_i,args_t) = List.split args in
			let args_v = List.map (fun a -> value_of_type a) args_t in
			let (ll,s') = allocatelist(!s,args_v) in
			let r' = bindlist(emptyenv,args_i,ll) in
			let bt = type_inf (fst f) r' (ref s') in
			if (bt == snd f)
				then FunT(args_t,snd f)
				else failwith "body type doesn't match declared type"
  		(* type_of_value (makefun(e,r)) would be the easy-way, *)
			(* but it does not perform checks on the exprs *)
	| EApplyf (f, args) -> 
			(let clos_t = type_inf f r s in
			let args_t = type_inf_list args r s in
			match clos_t with 
			| FunT(at,rt) -> 
  				if (args_t = at)
  					then rt
  					else failwith "argument type doesn't match declared type"
			| _ -> 	failwith "not a function in application position" )
	| ERecf (name, expr) ->
		type_of_value (makefunrec(name,expr,r,s))
	| ERef expr -> RefT (ref(type_inf expr r s))
	| EDeref exprr -> 
			(match (type_inf exprr r s) with
			| RefT typr -> (!typr)
			| _ -> failwith "Trying to dereference a non-reference in type_inf")
	| ESeq (a, b) -> type_inf b r s
  | EAssign (i, expr) -> UndefinedT
  | EBreak  -> UndefinedT
  | EContinue  -> UndefinedT
  | EReturn expr -> type_inf expr r s
	| EWhile (c, body) -> 
			if (type_inf c r s == BoolT)
			then UndefinedT
			else failwith "wrong guard in EWhile"
	| EPrint expr -> UndefinedT
	| ESleepf secs -> UndefinedT
	| EEval a -> type_inf a r s (*there is no such thing as a deferred type*)


and type_inf_list l r s = match l with
  |  [] -> []
  | hd::tl -> type_inf (hd) r s::(type_inf_list tl r s)

;;


(* run time *)
type prog = Program of (ide * exp) list * exp;;


(* valutazione di dichiarazione: restituisce un ambiente e uno store globale *)
let dval (decls : (ide * exp) list) =
	let decls_i = List.map (fun a -> fst a) decls in
	let decls_v =
			(sem_eager_list (List.map (fun a -> snd a) decls) emptyenv (ref emptystore)) in
	let (ll, s) = allocatelist (emptystore, decls_v)
	in ((bindlist (emptyenv, decls_i, ll)), s)
;;
(* eval program *)
let peval (p : prog) =
	match p with
	| Program (decls, expr) ->
			let (rho, sigma) = dval decls in sem_eager expr rho (ref sigma)
;;
	
(* ================================================================= *)
(* ============================= TESTS ============================= *)
(* ================================================================= *)

(* let sigma0 = ref emptystore;; *)
(* let rho0 = emptyenv;;         *)

(* let p1 =                                                                                                          *)
(* 	Program ([("var0",EInt 100)],                                                                                   *)
(* 		(ELet ("var1",                                                                                                *)
(* 			(EIfthenelse ((EBool false), (ESum ((EIde "var0"), (EInt 1))), (ESum ((EIde "var0"), (EInt (-1)))))),       *)
(* 			(EIde "var1"))))                                                                                            *)
(* ;;                                                                                                                *)
(* peval p1;;                                                                                                        *)
	
	
(* let eint_identity = EFund ([ "x", IntT ], (EIde "x",IntT));;                                                      *)
(* let aeint_identity x = EApplyf (eint_identity, [ x ]);;                                                           *)
	
(* let eassign = ELet("i", (ERef (EInt 1)),                                                                          *)
(* 								ESeq(	ESeq(EPrint (EIde "i"),                                                                    *)
(* 								EAssign ("i", (ESum ((EDeref (EIde "i")), (EInt 1))))),                                           *)
(* 								EDeref(EIde "i")));;                                                                              *)
(* sem_eager eassign rho0 sigma0;;                                                                                   *)

(* let ewhile =                                                                                                      *)
(* 	EFund ([ "i", RefT (ref IntT); "n", IntT ],                                                                     *)
(* 		(EWhile ((ELessint ((EDeref (EIde "i")), (EIde "n"))),                                                        *)
(* 			(ESeq ((EPrint (EDeref (EIde "i"))),                                                                        *)
(* 					(EAssign ("i", (ESum ((EDeref (EIde "i")), (EInt 1)))))))),UndefinedT))                                 *)
(* ;;                                                                                                                *)
(* let aewhile03 = EApplyf (ewhile, [ ERef (EInt 0); EInt 3 ]);;                                                     *)
(* sem_eager aewhile03 rho0 sigma0;;                                                                                 *)

(* let ebreak =                                                                                                      *)
(* 	EFund ([ "i", IntT; "n", IntT ; "stop",IntT],                                                                   *)
(* 		(EWhile ((ELessint ((EDeref (EIde "i")), (EIde "n"))),                                                        *)
(* 			(ESeq ((EPrint (EDeref (EIde "i"))),                                                                        *)
(* 					EIfthenelse( ENot(ELessint(EDeref(EIde "i"), EIde "stop")),                                             *)
(* 					ESeq( EAssign ("i", (ESum ((EDeref (EIde "i")), (EInt 2)))),EBreak),                                    *)
(* 					(EAssign ("i", (ESum ((EDeref (EIde "i")), (EInt 1))))))))),UndefinedT))                                *)
(* ;;                                                                                                                *)

(* let aebreak = EApplyf (ebreak, [ ERef (EInt 0); EInt 10; EInt 6]);;                                               *)
(* sem_eager aebreak rho0 sigma0;;                                                                                   *)


(* let fun1 = EFund ([ "x", IntT ], (EFund ([ "y",IntT], (ESum ((EIde "x"), (EIde "y")),IntT)),FunT([IntT],IntT)));; *)
(* let afun1 = EApplyf (fun1, [ EInt 3 ]);;                                                                          *)
(* sem_eager afun1 rho0 sigma0;;                                                                                     *)
(* let aafun1 = EApplyf (afun1, [ EInt 5 ]);;                                                                        *)
(* sem_eager aafun1 rho0 sigma0;;                                                                                    *)
	
(* let esucc = EFund ([ "x", IntT ], (ESum ((EIde "x"), (EInt 1)),IntT));;                                           *)
(* let e1 = ELet ("succ", esucc,	(ELet ("y", (EInt 5), (EApplyf ((EIde "succ"), [ EIde "y" ])))));;                 *)
(* sem_eager e1 rho0 sigma0;;                                                                                        *)

(* let recfact =                                                                                                     *)
(* 	ERecf ("fatt",                                                                                                  *)
(* 		(EFund ([ ("x",IntT) ],                                                                                       *)
(* 			(EIfthenelse ((EEqint ((EIde "x"), (EInt 1))), (EInt 1),                                                    *)
(* 					(EProd ((EApplyf ((EIde "fatt"), [ EDiff ((EIde "x"), (EInt 1)) ])),                                    *)
(* 						(EIde "x")))),IntT))))                                                                                *)
(* ;;                                                                                                                *)

(* let iterfact =                                                                                                    *)
(* 	EFund ([ ("n",IntT) ],                                                                                          *)
(* 		(ELet ("result", (ERef (EInt 1)),                                                                             *)
(* 			(ELet ("i", (ERef (EInt 1)),                                                                                *)
(* 					(ESeq                                                                                                   *)
(* 						((EWhile                                                                                              *)
(* 								((ELessint ((EDeref (EIde "i")),                                                                  *)
(* 										(ESum ((EIde "n"), (EInt 1))))),                                                              *)
(* 								(ESeq                                                                                             *)
(* 										((EAssign ("result",                                                                          *)
(* 												(EProd ((EDeref (EIde "result")), (EDeref (EIde "i")))))),                                *)
(* 										(EAssign ("i", (ESum ((EDeref (EIde "i")), (EInt 1))))))))),                                  *)
(* 						(EReturn(EDeref (EIde "result")))))))),IntT))                                                         *)
(* ;;                                                                                                                *)

(* let arecfact5 = EApplyf (recfact, [ EInt 5 ]);;                                                                   *)
(* let aiterfact6 = EApplyf (iterfact, [ EInt 6 ]);;                                                                 *)
(* sem_eager arecfact5 rho0 sigma0;;                                                                                 *)
(* sem_eager aiterfact6 rho0 sigma0;;                                                                                *)
	
(* let (fields0,meths0) =                                                                                            *)
(* 	([ ("five", (EInt 5));                                                                                          *)
(* 	("x", (ERef (EInt 100)));                                                                                       *)
(* 	("s", (EString "This is a string")) ],                                                                          *)
		
(* 	[("get_s", EFund ([], (EIde "s",StringT)));                                                                     *)
(* 	(* ("get_x", (EIde "x")); wont work, must be an EFund and the label must be unique!*)                           *)
(* 	("get_x", EFund ([], (EIde "x",IntT))); (*this is ok instead*)                                                  *)
(* 	("set_x_then_get", EFund ([ "y", IntT ], (ESeq(EAssign("x", (EIde "y")),EIde "x"),IntT) ));                     *)
(* 	("inc5_x_then_print", EFund([],(ESeq(EAssign("x", ESum((EDeref (EIde "x")), EIde "five")),                      *)
(* 																			(EPrint(EIde "x"))), UndefinedT)));                                         *)
(* 	("this_inc5", EFund ([], (EApplyf(EIde "inc5_x_then_print",[]),UndefinedT))) ])                                 *)
(* ;;                                                                                                                *)
		

(* let erecord0 = ENewRecord (fields0,meths0);;                                                                      *)
(* sem_eager erecord0 rho0 sigma0;;                                                                                  *)

(* let emethod00 = ERecordMethod (erecord0, "get_s", []);;                                                           *)
(* let emethod01 = ERecordMethod (erecord0, "set_x_then_get", [EInt 1023]);;                                         *)
(* let emethod02 = ERecordMethod (erecord0, "inc5_x_then_print", []);;                                               *)
(* let emethod03 = ERecordMethod (erecord0, "this_inc5", []);;                                                       *)

(* sem_eager emethod03 rho0 sigma0;;                                                                                 *)

(* (*be like: let a = erecord0 in let b = a.this_inc5 in a.this_inc5 *)                                              *)
(* let ethis_inc5_in_this_inc5 =                                                                                     *)
(* 	ELet ("a", erecord0,                                                                                            *)
(* 		(ELet ("b",                                                                                                   *)
(* 			(ERecordMethod ((EIde "a"), "this_inc5", [])),                                                              *)
(* 			(ERecordMethod ((EIde "a"), "this_inc5", [])))))                                                            *)
(* ;;                                                                                                                *)
(* sem_eager ethis_inc5_in_this_inc5 rho0 sigma0;;                                                                   *)
	

(* sem_eager (ESleepf 4) rho0 sigma0                                                                                 *)

(* let easync = EEval(aiterfact6);;                                                                                  *)
(* let easync2 = ESum(EEval(ESeq(ESleepf 5,aiterfact6)),ESum(EEval(aiterfact6),EInt 100));;                          *)
(* sem_eager easync2 rho0 sigma0                                                                                     *)
